﻿using System;
namespace Location.Persistence.LocationDa
{
    public class LocationDa
    {
        public LocationDa()
        {
        }
    }
}
