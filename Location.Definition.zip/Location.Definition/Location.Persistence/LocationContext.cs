﻿using System;
using Microsoft.EntityFrameworkCore;

namespace Location.Persistence
{
    public class LocationContext : DbContext
    {
        public LocationContext()
        {
        }
    }
}
